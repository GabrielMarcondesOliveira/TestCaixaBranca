package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Esta classe é responsável por realizar operações de login dentro do sistema.
 * Além de inclui métodos para conexão com o banco de dados inserido e verificação de credenciais de usuário.
 */
public class User {

    /**
     * Método para conectar ao banco de dados MySQL.
     * 
     * @return Objeto Connection representa a conexão com o banco de dados,
     *         ou retorna null em caso de falha na conexão.
     */
    public Connection conectarBD() {
        Connection conn = null;
        try {
            // essa classe faz carregar o driver do MySQL
            Class.forName("com.mysql.Driver").newInstance();

            // essa variável é criada para armazeanar a URL do banco de dados e fazer assim a conexão
            String url = "jdbc:mysql://127.0.0.1/test?user=lopes&password=123";

            // Aqui a conexão está sendo criada e estabelecida
            conn = DriverManager.getConnection(url);
        } catch (Exception e) {
            // A exceção criada é para caso dê erro na conexão com o banco de dados
        }
        return conn;
    }

    /** Variável para o nome do usuário */
    public String nome = "";

    /** Indicador que a operação foi concluída sem erro */
    public boolean result = false;

    /**
     * Verificação do usuário e senha que foram inseridos se estão corretos.
     * 
     * @param login Login do usuário.
     * @param senha Senha do usuário.
     * @return true se o login for foi concluída a operação, false caso contrário.
     */
    public boolean verificarUsuario(String login, String senha) {
        String sql = "";
        Connection conn = conectarBD();

        // INSTRUÇÃO SQL para consulta de login e senha
        sql = "SELECT nome FROM usuarios ";
        sql += "WHERE login = '" + login + "'";
        sql += " AND senha = '" + senha + "'";

        try {
            // Cria uma declaração para executar a consulta SQL
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            // Verifica se o usuário foi encontrado
            if (rs.next()) {
                result = true;
                nome = rs.getString("nome");
            }
        } catch (Exception e) {
            // Tratamento silencioso de exceções
        }
        return result;
    }
} // fim da classe

